import java.util.*;

public class Aging {

    static class Pagina {
        int numero;
        int contador;
        boolean referenciada;

        public Pagina(int numero) {
            this.numero = numero;
            this.contador = 0;
            this.referenciada = true;
        }

        @Override
        public String toString() {
            return numero + ":" + String.format("%8s", Integer.toBinaryString(contador & 0xFF)).replace(' ', '0');
        }
    }

    private int capacidade;
    private int pageFaults;
    private List<Pagina> memoria = new ArrayList<>();

    public Aging(int capacidade) {
        this.capacidade = capacidade;
        this.pageFaults = 0;
    }

    public void acessoPagina(int numero) {
        System.out.printf("%-20s", "Página: " + numero);
        boolean achou = false;

        for (Pagina p : memoria) {
            if (p.numero == numero) {
                p.referenciada = true;
                achou = true;
                break;
            }
        }

        if (!achou) {
            pageFaults++;
            if (memoria.size() == capacidade) {
                atualizarContadores();
                Pagina menosUsada = Collections.min(memoria, Comparator.comparingInt(p -> p.contador));
                memoria.remove(menosUsada);
            }
            Pagina nova = new Pagina(numero);
            memoria.add(nova);
        }

        atualizarContadores();
        mostrarEstadoMemoria(achou);
    }

    private void atualizarContadores() {
        for (Pagina p : memoria) {
            p.contador >>= 1;
            if (p.referenciada) {
                p.contador |= 0b10000000;
                p.referenciada = false;
            }
        }
    }

    private void mostrarEstadoMemoria(boolean hit) {
        System.out.print("| Memória: ");
        for (Pagina p : memoria) {
            System.out.print("[" + p + "] ");
        }
        System.out.print("| " + (hit ? "HIT" : "PAGE FAULT"));
        System.out.println();
    }

    public int getPageFaults() {
        return pageFaults;
    }

    public static void main(String[] args) {
        List<Integer> paginas = Arrays.asList(0, 1, 2, 3, 0, 1, 4, 0, 1, 2, 3, 4);
        int capacidade = 3;

        System.out.println("=============================");
        System.out.println(" ALGORITMO AGING");
        System.out.println("=============================\n");

        Aging aging = new Aging(capacidade);
        long inicio = System.nanoTime();

        System.out.printf("%-20s%-40s\n", "Página Acessada", "Estado da Memória");
        System.out.println("-------------------------------------------------------------------");
        for (int pagina : paginas) {
            aging.acessoPagina(pagina);
        }

        long fim = System.nanoTime();
        long tempo = fim - inicio;

        System.out.println("\n-------------------------------------------------------------------");
        System.out.println("Total de page faults: " + aging.getPageFaults());
        System.out.printf("Tempo de execução: %.6f ms\n", tempo / 1_000_000.0);
    }
}
