import java.util.*;

public class Comparador {

    public static void main(List<Integer> paginas, int capacidade) {
        Scanner scanner = new Scanner(System.in);

        exibirCabecalho();

        long inicio, fim;

        System.out.println("Iniciando o algoritmo Aging...");
        inicio = System.nanoTime();
        Aging aging = new Aging(capacidade);
        for (int pagina : paginas) {
            aging.acessoPagina(pagina);
        }
        fim = System.nanoTime();
        long tempoAging = fim - inicio;
        imprimirResultados("Aging", aging.getPageFaults(), tempoAging);

        System.out.println("\nIniciando o algoritmo Clock...");
        inicio = System.nanoTime();
        Clock clock = new Clock(capacidade);
        for (int pagina : paginas) {
            clock.acessarPagina(pagina);
        }
        fim = System.nanoTime();
        long tempoClock = fim - inicio;
        imprimirResultados("Clock", clock.getPageFaults(), tempoClock);

        System.out.println("\nIniciando o algoritmo FIFO...");
        inicio = System.nanoTime();
        FIFO fifo = new FIFO(capacidade);
        fifo.processarPaginas(paginas);
        fim = System.nanoTime();
        long tempoFIFO = fim - inicio;
        imprimirResultados("FIFO", fifo.getPageFaults(), tempoFIFO);

        System.out.println("\nIniciando o algoritmo LRU...");
        inicio = System.nanoTime();
        LRU lru = new LRU(capacidade);
        lru.processarPaginas(paginas);
        fim = System.nanoTime();
        long tempoLRU = fim - inicio;
        imprimirResultados("LRU", lru.getPageFaults(), tempoLRU);

        exibirResumoFinal(aging, tempoAging, clock, tempoClock, fifo, tempoFIFO, lru, tempoLRU);
    }

    private static void exibirCabecalho() {
        System.out.println("===============================");
        System.out.println(" COMPARADOR DE ALGORITMOS");
        System.out.println("===============================\n");
    }

    private static void imprimirResultados(String algoritmo, int pageFaults, long tempo) {
        System.out.println("\n===============================");
        System.out.println(" ALGORITMO " + algoritmo);
        System.out.println("===============================");
        System.out.printf("Total de Page Faults: %-15d\n", pageFaults);
        System.out.printf("Tempo de execução: %-15.6f ms\n", tempo / 1_000_000.0);
        System.out.println("-----------------------------------------------");
    }

    private static void exibirResumoFinal(Aging aging, long tempoAging, Clock clock, long tempoClock, FIFO fifo, long tempoFIFO, LRU lru, long tempoLRU) {
        System.out.println("\n===============================");
        System.out.println(" RESUMO FINAL");
        System.out.println("===============================");
        System.out.printf("%-10s | %-15s | %-15s\n", "Algoritmo", "Page Faults", "Tempo (ms)");
        System.out.println("-----------------------------------------------");
        System.out.printf("%-10s | %-15d | %-15.6f\n", "Aging", aging.getPageFaults(), tempoAging / 1_000_000.0);
        System.out.printf("%-10s | %-15d | %-15.6f\n", "Clock", clock.getPageFaults(), tempoClock / 1_000_000.0);
        System.out.printf("%-10s | %-15d | %-15.6f\n", "FIFO", fifo.getPageFaults(), tempoFIFO / 1_000_000.0);
        System.out.printf("%-10s | %-15d | %-15.6f\n", "LRU", lru.getPageFaults(), tempoLRU / 1_000_000.0);
        System.out.println("===============================");
    }
}
