import java.util.*;

public class Clock {

    static class Pagina {
        int numero;
        boolean bitReferencia;

        public Pagina(int numero) {
            this.numero = numero;
            this.bitReferencia = true;
        }
    }

    private Pagina[] memoria;
    private int ponteiro;
    private int capacidade;
    private int pageFaults;

    public Clock(int capacidade) {
        this.capacidade = capacidade;
        this.memoria = new Pagina[capacidade];
        this.ponteiro = 0;
        this.pageFaults = 0;
    }

    public void acessarPagina(int numero) {
        boolean encontrado = false;

        for (Pagina p : memoria) {
            if (p != null && p.numero == numero) {
                p.bitReferencia = true;
                encontrado = true;
                break;
            }
        }

        if (!encontrado) {
            pageFaults++;

            while (true) {
                if (memoria[ponteiro] == null) {
                    memoria[ponteiro] = new Pagina(numero);
                    avancarPonteiro();
                    break;
                } else if (!memoria[ponteiro].bitReferencia) {
                    memoria[ponteiro] = new Pagina(numero);
                    avancarPonteiro();
                    break;
                } else {
                    memoria[ponteiro].bitReferencia = false;
                    avancarPonteiro();
                }
            }
        }

        imprimirMemoria(numero, encontrado);
    }

    private void avancarPonteiro() {
        ponteiro = (ponteiro + 1) % capacidade;
    }

    private void imprimirMemoria(int numero, boolean hit) {
        System.out.printf("%-20s", "Página: " + numero);
        System.out.print("| Memória: [ ");
        for (Pagina p : memoria) {
            if (p != null) {
                System.out.print(p.numero + " ");
            } else {
                System.out.print("_ ");
            }
        }
        System.out.println("] | " + (hit ? "HIT" : "PAGE FAULT"));
    }

    public int getPageFaults() {
        return pageFaults;
    }

    public static void main(String[] args) {
        List<Integer> paginas = Arrays.asList(0, 1, 2, 3, 0, 1, 4, 0, 1, 2, 3, 4);
        int capacidade = 3;

        System.out.println("\n=============================");
        System.out.println(" ALGORITMO CLOCK");
        System.out.println("=============================\n");

        Clock clock = new Clock(capacidade);
        long inicio = System.nanoTime();

        System.out.printf("%-20s%-30s\n", "Página Acessada", "Memória");
        System.out.println("-------------------------------------------------------------");

        for (int pagina : paginas) {
            clock.acessarPagina(pagina);
        }

        long fim = System.nanoTime();
        long tempo = fim - inicio;

        System.out.println("-------------------------------------------------------------");
        System.out.println("Total de Page Faults: " + clock.getPageFaults());
        System.out.printf("Tempo de execução: %.6f ms\n", tempo / 1_000_000.0);
    }
}
