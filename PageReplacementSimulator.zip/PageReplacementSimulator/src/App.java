import java.util.*;

public class App {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Digite a capacidade da memoria:");
        int capacidade = scanner.nextInt();

        System.out.println("Digite as páginas a serem acessadas (separadas por espaco):");
        scanner.nextLine();
        String paginasInput = scanner.nextLine();
        List<Integer> paginas = new ArrayList<>();
        for (String pagina : paginasInput.split(" ")) {
            paginas.add(Integer.parseInt(pagina));
        }

        System.out.println("Escolha o algoritmo (1 - Aging, 2 - Clock, 3 - FIFO, 4 - LRU):");
        int escolhaAlgoritmo = scanner.nextInt();

        if (escolhaAlgoritmo == 1) {
            System.out.println("\nIniciando o algoritmo Aging...");
            Aging aging = new Aging(capacidade);
            long inicio = System.nanoTime();
            for (int pagina : paginas) {
                aging.acessoPagina(pagina);
            }
            long fim = System.nanoTime();
            long tempo = fim - inicio;
            System.out.println("Total de page faults: " + aging.getPageFaults());
            System.out.printf("Tempo de execução: %.6f ms\n", tempo / 1_000_000.0);
        } else if (escolhaAlgoritmo == 2) {
            System.out.println("\nIniciando o algoritmo Clock...");
            Clock clock = new Clock(capacidade);
            long inicio = System.nanoTime();
            for (int pagina : paginas) {
                clock.acessarPagina(pagina);
            }
            long fim = System.nanoTime();
            long tempo = fim - inicio;
            System.out.println("Total de page faults: " + clock.getPageFaults());
            System.out.printf("Tempo de execução: %.6f ms\n", tempo / 1_000_000.0);
        } else if (escolhaAlgoritmo == 3) {
            System.out.println("\nIniciando o algoritmo FIFO...");
            FIFO fifo = new FIFO(capacidade);
            long inicio = System.nanoTime();
            fifo.processarPaginas(paginas);
            long fim = System.nanoTime();
            long tempo = fim - inicio;
            System.out.println("Total de page faults: " + fifo.getPageFaults());
            System.out.printf("Tempo de execução: %.6f ms\n", tempo / 1_000_000.0);
        } else if (escolhaAlgoritmo == 4) {
            System.out.println("\nIniciando o algoritmo LRU...");
            LRU lru = new LRU(capacidade);
            long inicio = System.nanoTime();
            lru.processarPaginas(paginas);
            long fim = System.nanoTime();
            long tempo = fim - inicio;
            System.out.println("Total de page faults: " + lru.getPageFaults());
            System.out.printf("Tempo de execução: %.6f ms\n", tempo / 1_000_000.0);
        } else {
            System.out.println("Opção de algoritmo inválida.");
        }

        System.out.println("\nDeseja comparar os algoritmos? (1 - Sim, 2 - Não):");
        int comparar = scanner.nextInt();
        if (comparar == 1) {
            Comparador.main(paginas, capacidade);
        }

        scanner.close();
    }
}
