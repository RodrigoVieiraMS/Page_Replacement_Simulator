import java.util.*;

public class FIFO {

    private final int capacidade;
    private final Set<Integer> memoria;
    private final Queue<Integer> filaFIFO;
    private int faltas;

    public FIFO(int capacidade) {
        this.capacidade = capacidade;
        this.memoria = new HashSet<>();
        this.filaFIFO = new LinkedList<>();
        this.faltas = 0;
    }

    public void processarPaginas(List<Integer> paginas) {
        System.out.println("=============================");
        System.out.println(" ALGORITMO FIFO");
        System.out.println("=============================\n");

        System.out.printf("%-20s%-30s\n", "Página Acessada", "Memória");
        System.out.println("--------------------------------------------------");

        for (int pagina : paginas) {
            boolean hit = memoria.contains(pagina);
            if (!hit) {
                faltas++;

                if (memoria.size() == capacidade) {
                    int removida = filaFIFO.poll();
                    memoria.remove(removida);
                }

                memoria.add(pagina);
                filaFIFO.offer(pagina);
            }

            System.out.printf("%-20s", "Página: " + pagina);
            System.out.print("| Memória: " + filaFIFO + " | ");
            System.out.println(hit ? "HIT" : "PAGE FAULT");
        }

        System.out.println("--------------------------------------------------");
    }

    public int getPageFaults() {
        return faltas;
    }

    public static void main(String[] args) {
        List<Integer> paginas = Arrays.asList(0, 1, 2, 3, 0, 1, 4, 0, 1, 2, 3, 4);
        int capacidade = 3;

        FIFO fifo = new FIFO(capacidade);
        long inicio = System.nanoTime();
        fifo.processarPaginas(paginas);
        long fim = System.nanoTime();
        long duracao = fim - inicio;

        System.out.println("Total de Page Faults: " + fifo.getPageFaults());
        System.out.printf("Tempo de execução: %.6f ms\n", duracao / 1_000_000.0);
    }
}
