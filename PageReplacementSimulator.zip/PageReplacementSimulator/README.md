
---

# Simulador de Algoritmos de Substituição de Páginas

Este projeto simula os algoritmos de substituição de páginas: **FIFO**, **LRU**, **Clock** e **Aging**. Você pode rodar cada algoritmo individualmente com dados prontos ou usar o simulador completo com entrada personalizada para comparar os algoritmos.

## 📁 Estrutura do Projeto

Os arquivos Java estão localizados na pasta `src/`.

```
src/
├── Aging.java
├── Clock.java
├── FIFO.java
├── LRU.java
├── App.java
```

---

## ▶️ Como Compilar e Executar

### 1. Compile todos os arquivos:

```bash
javac -d bin src/*.java
```

---

### 2. Executar o simulador completo (personalizado):

```bash
java -cp bin App
```

Ao rodar o `App.java`, você poderá:

* Informar a **capacidade da memória** (número de quadros);
* Informar a **sequência de páginas** (separadas por espaço);
* Escolher qual algoritmo deseja rodar ou comparar **todos** de uma vez.

---

### 3. Executar algoritmos individualmente (modo rápido):

Se quiser apenas ver o funcionamento de um algoritmo com dados de exemplo pré-definidos (mockados), você pode executar diretamente o arquivo correspondente:

```bash
java -cp bin Aging
java -cp bin Clock
java -cp bin FIFO
java -cp bin LRU
```

> ⚠️ Nestes casos, os algoritmos usam os dados mockados abaixo:

```java
List<Integer> paginas = Arrays.asList(0, 1, 2, 3, 0, 1, 4, 0, 1, 2, 3, 4);
int capacidade = 3;
```

---

## ✅ Resumo

| Opção                    | Vantagem                                            |
| ------------------------ | --------------------------------------------------- |
| `java -cp bin App`       | Entrada personalizada e comparação entre algoritmos |
| `java -cp bin Nome.java` | Teste rápido de cada algoritmo com dados prontos    |

---
